#include <Arduino.h>
#include <Adafruit_BMP085.h>
#include <SPI.h>
#include <Wire.h>
#include "DHTesp.h" // Click here to get the library: http://librarymanager/All#DHTesp
#ifdef ESP32
#pragma message(THIS EXAMPLE IS FOR ESP8266 ONLY!)
#error Select ESP8266 board.
#endif

Adafruit_BMP085 bmp;
DHTesp dht;

void setup()
{
  Serial.begin(9600);

  if (!bmp.begin()) {
	Serial.println("Could not find a valid BMP085 sensor, check wiring!");
  }

  String thisBoard= ARDUINO_BOARD;
  Serial.println(thisBoard);

  // Autodetect is not working reliable, don't use the following line
  // dht.setup(17);
  // use this instead: 
  dht.setup(D4, DHTesp::DHT22); // Connect DHT sensor to GPIO 17
}

void loop()
{
  float Temperature = bmp.readTemperature();
  float pressure = bmp.readRawPressure();
  float seaPressure = bmp.readSealevelPressure();
  float altitude = bmp.readAltitude();
  
  Serial.print("\t");
  Serial.print("Temperature: ");
  Serial.print(Temperature);
  Serial.print("\t");
  Serial.print("Pressure: ");
  Serial.println(pressure);
  Serial.print("\t");
  Serial.print("SeaPressure: " );
  Serial.println(seaPressure);
  Serial.print("\t");
  Serial.print("Altitude: ");
  Serial.println(altitude);

  
  delay(dht.getMinimumSamplingPeriod());

  float humidity = dht.getHumidity();
  float temperature = dht.getTemperature();

  Serial.print("\t");
  Serial.print("temperature: ");
  Serial.println(temperature);
  Serial.print("\t");
  Serial.print("Humidity: ");
  Serial.println(humidity);

  
  delay(2000);
}